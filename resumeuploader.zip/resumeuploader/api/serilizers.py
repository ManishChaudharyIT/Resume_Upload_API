from rest_framework.response import Response
from rest_framework import serializers
from api.models import Profile


class ProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = Profile
        fields = ['id', 'name', 'email', 'dob', 'state',
                  'gender', 'location', 'profile_img', 'rdoc']
